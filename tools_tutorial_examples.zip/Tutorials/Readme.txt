Welcome to the BigWorld toolkit artist training tutorials.

The 'helper_maps folder' contains the helper bitmaps for identifying portals and hardpoints.
The 'bigworld_material_library' folder contains a max file to be used as a BigWorld material library.
The 'working_files' folder contains 3dsMax assets refered to within the content creation manual.
The 'empty_file_structure' folder contains an empty folder structure resembling the folder structure used within the Fantasy Demo that you may wish to use for your project